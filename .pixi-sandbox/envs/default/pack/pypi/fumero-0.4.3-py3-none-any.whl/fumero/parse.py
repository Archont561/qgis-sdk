"""Read a Python module with griffe and describe it in [`fumero.model`] terms.

This is the only part of fumero that knows griffe exists. Everything downstream works from the
model, so a change in how a module is introspected never reaches the output.

Start at [`load_module`], which reads a module and hands back the tree the rest of this module
takes apart.
"""

import ast
import re
from collections.abc import Sequence
from pathlib import Path
from typing import cast

import griffe

from .config import Config, Dialect
from .error import ModuleNotFound
from .model import Admonition, Class, Function, ParsedDocstring, Property

__all__ = [
    "is_own_member",
    "load_module",
    "module_attributes",
    "parse_class",
    "parse_class_definition",
    "parse_docstring",
    "parse_function",
    "parse_function_definition",
    "public_members",
    "strip_module_prefix",
    "strip_stdlib_prefixes",
]

# the standard library is shortened wherever it appears, since every reader already knows
# where these live and the path only crowds the signature
_STDLIB_PREFIXES = (
    "typing.",
    "builtins.",
    "collections.abc.",
    "typing_extensions.",
    "decimal.",
    "datetime.",
    "pathlib.",
)


def load_module(name: str, config: Config | None = None) -> griffe.Module:
    """Read a module and hand back griffe's view of it.

    A package is a module that happens to hold other modules, so either will do: `example` reads
    the whole package, `example.core` reads that subtree on its own.

    A module is read from its source where there is source to read. Where there is not, it is
    imported and read as the interpreter holds it, unless [`Config.no_inspect`] forbids it.

    A package whose `__init__` extends its `__path__` with `pkgutil.extend_path` is read whole,
    including the submodules that other distributions install beside it on `sys.path`.

    Args:
        name: An importable module path.
        config: Supplies the docstring dialect, and whether a module with no source may be
            imported to be read. Defaults are used when this is `None`.

    Returns:
        The module, and everything under it.

    Raises:
        ModuleNotFound: `name` is not importable from here.

    Examples:
        ```python
        module = load_module("example")
        ```
    """

    config = config or Config()
    loader = griffe.GriffeLoader(
        docstring_parser=griffe.Parser(config.dialect),
        docstring_options=_docstring_options(config.dialect),
        allow_inspection=not config.no_inspect,
    )
    loader.finder = _ExtendedPathFinder()
    try:
        loaded = loader.load(name, try_relative_path=False)
    except ImportError as error:
        raise ModuleNotFound(name) from error

    return cast(griffe.Module, loaded)


class _ExtendedPathFinder(griffe.ModuleFinder):
    """griffe's finder, which also looks where a package extends its `__path__` to.

    `pkgutil.extend_path` adds every directory of the package's name on `sys.path` to the package,
    which is how one package is split across distributions that install apart. griffe only treats
    a package as split when its `__init__` holds nothing but that call, and otherwise finds just
    the submodules beside the `__init__`.
    """

    def submodules(self, module: griffe.Module) -> list[tuple[tuple[str, ...], Path]]:
        found = super().submodules(module)
        if not _extends_path(module):
            return found

        names = {parts for parts, _ in found}
        own = cast(Path, module.filepath).parent
        for root in self.search_paths:
            directory = root.joinpath(*module.path.split("."))
            if directory == own or not directory.is_dir():
                continue
            for parts, path in self.iter_submodules(directory):
                # the first directory on the path wins, as it does on import
                if parts not in names:
                    names.add(parts)
                    found.append((parts, path))

        # a parent package has to be loaded before the modules inside it
        return sorted(found, key=lambda submodule: len(submodule[0]))


def _installed_apart(package: griffe.Module, member: griffe.Object | griffe.Alias) -> bool:
    """Whether `member` is a submodule found outside the package's own directory."""

    if not isinstance(member, griffe.Module):
        return False
    if not isinstance(package.filepath, Path) or not isinstance(member.filepath, Path):
        return False

    return package.filepath.parent not in member.filepath.parents


def _extends_path(module: griffe.Module) -> bool:
    """Whether the module is a package whose `__init__` assigns `__path__` from `extend_path`."""

    if not isinstance(module.filepath, Path) or module.filepath.name != "__init__.py":
        return False

    for node in ast.walk(ast.parse(module.filepath.read_text(encoding="utf-8"))):
        match node:
            case ast.Assign(
                targets=[ast.Name(id="__path__")],
                value=ast.Call(func=ast.Attribute(attr="extend_path") | ast.Name(id="extend_path")),
            ):
                return True

    return False


def _docstring_options(dialect: Dialect) -> griffe.DocstringOptions | None:
    """The parsing options a dialect needs, which is a fallback style for [`Dialect.AUTO`].

    griffe guesses a style by looking for a section header with a line above it. A docstring that
    opens with its first section has no line above it, so the guess finds nothing and the docstring
    goes unparsed: every section renders as prose, which is how a generated class whose docstring
    is a bare `Attributes:` block ends up printing that block verbatim.

    Naming a fallback settles it. A docstring the heuristics do not recognise is parsed as Google
    rather than not parsed at all, and one they do recognise is unaffected, since the fallback is
    only consulted once they have all missed.
    """

    if dialect is not Dialect.AUTO:
        return None

    return griffe.AutoOptions(default=griffe.Parser.google)


def public_members(
    module: griffe.Module, kind: griffe.Kind, config: Config
) -> list[griffe.Object | griffe.Alias]:
    """The members of `module` of one kind that belong in the documentation.

    `__all__` decides what is public. A module that defines one is taken at its word; a module that
    does not falls back to the convention that a leading underscore means private. So does a
    submodule another distribution installs into the package, which the package's `__all__` cannot
    name without breaking a star import wherever that distribution is missing.

    A class or a function is collected wherever it is bound, since re-exporting one from a package
    is how a curated API is written. A submodule is collected only where it lives, which is what
    keeps the walk finite: see [`is_own_member`].

    Args:
        module: The module to look through.
        kind: The kind of member to collect, such as `griffe.Kind.CLASS`.
        config: Supplies the exclude patterns.

    Returns:
        The matching members, in the order the module declares them, and submodules, which no
        module declares, by name.
    """

    exports = None if module.exports is None else {str(export) for export in module.exports}

    def is_public(name: str, member: griffe.Object | griffe.Alias) -> bool:
        if exports is None or _installed_apart(module, member):
            exported = not name.startswith("_")
        else:
            exported = name in exports

        return exported and not config.excludes(member)

    members = [
        member
        for name, member in module.members.items()
        if member.kind is kind
        and is_public(name, member)
        and (kind is not griffe.Kind.MODULE or is_own_member(module, member))
    ]
    # submodules arrive in the order the file system lists them, which differs between machines
    if kind is griffe.Kind.MODULE:
        members.sort(key=lambda member: member.name)

    return members


def is_own_member(
    parent: griffe.Object | griffe.Alias, member: griffe.Object | griffe.Alias
) -> bool:
    """Whether `parent` defines `member`, rather than importing it from somewhere else.

    This is what bounds the walk. Documentation nests, and a name bound in two places would
    otherwise be walked in both: a stub that writes `import package.module` binds the whole package
    inside its own submodule, so a walk that reads that as a child arrives back where it started
    and never finishes. PySide6 ships that line in nearly every stub it has.

    Applied to submodules and to nested classes, which are the two things walked into. It is
    deliberately not applied to the classes and functions on a module's own page, because
    re-exporting those from a package is how a curated API is written, and each is documented once
    wherever it is bound.

    Args:
        parent: The module or class being walked.
        member: One of its members.

    Returns:
        `True` when `parent` is where the member is defined.

    Examples:
        ```python
        is_own_member(package, package.members["core"])       # True, `package.core`
        is_own_member(package.core, core.members["package"])  # False, an import of the root
        ```
    """

    try:
        return member.canonical_path == f"{parent.canonical_path}.{member.name}"
    except (griffe.AliasResolutionError, griffe.CyclicAliasError):
        return False


def module_attributes(module: griffe.Module, config: Config) -> list[Property]:
    """The module's public attributes, sorted by name, each described by its own docstring.

    What is public is decided as for classes and functions, by `__all__` where the module defines
    one: see [`public_members`]. A name the module only imports for its own use stays off its page.

    Type aliases are attributes as far as griffe is concerned, which is what lets a signature link
    to one.

    Args:
        module: The module to look through.
        config: Supplies the exclude patterns.

    Returns:
        One [`fumero.model.Property`] per attribute.
    """

    attributes = [
        _attribute_property(attribute, attribute.docstring.value if attribute.docstring else None)
        for attribute in cast(
            list[griffe.Attribute], public_members(module, griffe.Kind.ATTRIBUTE, config)
        )
    ]

    return sorted(attributes, key=lambda attribute: attribute.name)


def parse_class(cls: griffe.Class, config: Config | None = None) -> Class:
    """A class and everything documented on its page.

    Nested classes are read too, since each one gets a page of its own. Methods and attributes are
    sorted by name, because declaration order is an implementation detail and a reader looking for
    one member wants to know where to find it.

    Args:
        cls: The class to read.
        config: Supplies the exclude patterns applied to its members. Without one, only the
            leading-underscore rule filters them.

    Returns:
        The parsed class.
    """

    config = config or Config()

    functions = [
        parse_function(function)
        for function in cls.functions.values()
        if not function.name.startswith("_") and not config.excludes(function)
    ]

    classes = [
        parse_class(cast(griffe.Class, member), config)
        for member in cls.members.values()
        if member.kind is griffe.Kind.CLASS
        and is_own_member(cls, member)
        and not member.name.startswith("_")
        and not config.excludes(member)
    ]

    docstring = parse_docstring(cls)
    described = {entry.name: entry.description for entry in docstring.attributes}
    attributes = [
        _attribute_property(
            attribute,
            attribute.docstring.value if attribute.docstring else described.get(attribute.name),
        )
        for attribute in cls.attributes.values()
        if not attribute.name.startswith("_") and not config.excludes(attribute)
    ]

    return Class(
        name=cls.name,
        docstring=docstring,
        definition=parse_class_definition(cls),
        constructor=_constructor(cls, docstring.parameters, attributes),
        attributes=attributes,
        functions=sorted(functions, key=lambda function: function.name),
        classes=sorted(classes, key=lambda nested: nested.name),
    )


def parse_function(function: griffe.Function) -> Function:
    """A function or a method, with its signature, its docstring, and its source.

    Args:
        function: The function to read.

    Returns:
        The parsed function. Its source is empty when the file it came from cannot be read.
    """

    try:
        source = function.source or ""
    except (KeyError, OSError, ValueError):
        source = ""

    return Function(
        name=function.name,
        docstring=parse_docstring(function),
        definition=parse_function_definition(function),
        source=source,
    )


def _constructor(
    cls: griffe.Class, documented: list[Property], attributes: list[Property]
) -> Function | None:
    """`__init__` or `__new__`, with the descriptions the class docstring gave its parameters.

    Google style documents constructor arguments on the class rather than on `__init__`, and a
    dataclass gets an `__init__` synthesised with no docstring at all, so the prose lives on the
    class far more often than on the function.

    A dataclass field is both an attribute and a constructor parameter, so an `Attributes:` entry
    describes the parameter of the same name. That saves writing each description twice and then
    keeping the two copies in step. An explicit `Args:` still wins where there is one.
    """

    member = _constructor_member(cls)
    if member is None:
        return None

    function = parse_function(member)

    descriptions = {entry.name: entry.description for entry in attributes if entry.description}
    descriptions.update(
        {entry.name: entry.description for entry in documented if entry.description}
    )

    for parameter in function.docstring.parameters:
        if parameter.description is None:
            parameter.description = descriptions.get(parameter.name)

    return function


def parse_docstring(parent: griffe.Alias | griffe.Class | griffe.Function) -> ParsedDocstring:
    """Split a docstring into the sections a page renders separately.

    The signature is read first, so every parameter and the return type are described whether the
    docstring mentions them or not. An `Args:` entry then fills in the prose for the parameter it
    names, which is why the parameter list stays in signature order rather than docstring order.

    Args:
        parent: The class or function to read.

    Returns:
        The sections of the docstring. A `parent` with no docstring at all still yields its
        parameters and return type, since those come from the signature.
    """

    parameters = [
        _parameter_property(parameter, parent.package.name)
        for parameter in _callable_parameters(parent)
    ]
    attributes = [
        _attribute_property(attribute)
        for attribute in parent.attributes.values()
        if not attribute.name.startswith("_")
    ]
    returns = _return_property(parent)

    if not parent.docstring:
        return ParsedDocstring(parameters=parameters, returns=_worth_a_section(returns))

    description: str | None = None
    raises: list[Property] = []
    admonitions: list[Admonition] = []

    for index, section in enumerate(parent.docstring.parsed):
        match section:
            case griffe.DocstringSectionText() if index == 0:
                description = section.value

            case griffe.DocstringSectionParameters():
                parameters = _described_parameters(parent, section.value)

            case griffe.DocstringSectionAttributes():
                attributes = _described_attributes(parent, section.value)

            case griffe.DocstringSectionReturns() | griffe.DocstringSectionYields():
                if returns is not None and section.value:
                    returns.description = section.value[0].description or None

            case griffe.DocstringSectionRaises():
                raises = [_raise_property(raised, parent.package.name) for raised in section.value]

            case griffe.DocstringSectionAdmonition():
                admonitions.append(_admonition(section))

            case griffe.DocstringSectionExamples():
                admonitions.extend(_examples(section))

    return ParsedDocstring(
        description, parameters, attributes, raises, admonitions, _worth_a_section(returns)
    )


def _described_parameters(
    parent: griffe.Alias | griffe.Class | griffe.Function,
    documented: list[griffe.DocstringParameter],
) -> list[Property]:
    """The signature's parameters, each carrying the prose its `Args:` entry gave it.

    An entry for `*args` or `**kwargs` is written with its stars, which the parameter's name does
    not have.
    """

    descriptions = {entry.name.lstrip("*"): entry.description for entry in documented}

    return [
        _parameter_property(parameter, parent.package.name, descriptions.get(parameter.name))
        for parameter in _callable_parameters(parent)
    ]


def _described_attributes(
    parent: griffe.Alias | griffe.Class | griffe.Function,
    documented: list[griffe.DocstringAttribute],
) -> list[Property]:
    """The attributes as declared, each carrying the prose its `Attributes:` entry gave it."""

    descriptions = {entry.name: entry.description for entry in documented}

    return [
        _attribute_property(attribute, descriptions.get(attribute.name))
        for attribute in parent.attributes.values()
        if not attribute.name.startswith("_")
    ]


def _return_property(parent: griffe.Alias | griffe.Class | griffe.Function) -> Property | None:
    """The return value read from the signature, before a `Returns:` section describes it."""

    if parent.kind is not griffe.Kind.FUNCTION:
        return None

    if not isinstance(parent, griffe.Alias | griffe.Function):
        return None

    module = parent.package.name
    annotation = _annotation(parent.returns, module) if parent.returns is not None else None

    return Property(parent.name, annotation, None, None, _own_types(parent.returns, module))


def _worth_a_section(returns: Property | None) -> Property | None:
    """The return value, unless a section for it could only say `None`.

    A function that returns `None`, or whose return type is not written down, and whose docstring
    says nothing about what it returns, has no return worth a section. Its signature already shows
    `-> None` where it is written.
    """

    if returns is not None and returns.description is None and returns.annotation in (None, "None"):
        return None

    return returns


def _raise_property(documented: griffe.DocstringRaise, module: str) -> Property:
    """One `Raises:` entry, named after the exception it records."""

    annotation = (
        _annotation(documented.annotation, module) if documented.annotation is not None else None
    )

    return Property(
        annotation or "",
        annotation,
        documented.description or None,
        None,
        _own_types(documented.annotation, module),
    )


def _admonition(section: griffe.DocstringSectionAdmonition) -> Admonition:
    kind = str(section.value.kind)

    return Admonition(kind, section.title or kind.title(), section.value.contents)


def _examples(section: griffe.DocstringSectionExamples) -> list[Admonition]:
    """An `Examples:` section, split into the prose and the doctests it alternates between.

    Prose arrives as markdown and passes through as written; a doctest arrives as bare source and
    needs a fence put round it, which the template does once it knows which is which.
    """

    return [
        Admonition(
            "example" if kind is griffe.DocstringSectionKind.examples else "markdown",
            section.title or "Example",
            content,
        )
        for kind, content in section.value
    ]


def _parameter_property(
    parameter: griffe.Parameter, module: str, description: str | None = None
) -> Property:
    annotation = (
        _annotation(parameter.annotation, module) if parameter.annotation is not None else None
    )

    return Property(
        parameter.name,
        annotation,
        description,
        _default(parameter),
        _own_types(parameter.annotation, module),
    )


def _default(parameter: griffe.Parameter) -> str | None:
    """A parameter's default as a reader should see it, or `None` when it has none.

    A default that names something private, such as a sentinel told apart from `None`, is shown as
    `...`: the reader can neither see nor pass the name, and only needs to know that the parameter
    has a default, which its description explains. `*args` and `**kwargs` have none, though griffe
    records the empty tuple and dict they start as.
    """

    variadic = {griffe.ParameterKind.var_positional, griffe.ParameterKind.var_keyword}
    if parameter.default is None or parameter.kind in variadic:
        return None

    return "..." if _names_private(parameter.default) else str(parameter.default)


def _names_private(expression: object) -> bool:
    """Whether `expression` names something private, such as `_KEEP` or `_field(init=False)`.

    A leading underscore marks a name private, as it does everywhere else here, but a dunder such
    as `__debug__` is not. Only a parsed expression can be checked; a default read from a compiled
    module arrives as text, and is shown as it is.
    """

    return isinstance(expression, griffe.Expr) and any(
        isinstance(part, griffe.ExprName)
        and part.name.startswith("_")
        and not (part.name.startswith("__") and part.name.endswith("__"))
        for part in expression.iterate()
    )


def parse_function_definition(function: griffe.Function, width: int = 84) -> str:
    """The `def` line as documentation shows it, rather than as the interpreter sees it.

    A leading `self` or `cls` is dropped, because it is not something a caller passes, and there is
    no trailing colon, because this is a thing to read rather than a line to run.

    A definition too long for `width` breaks one parameter to a line. That is the only reason a
    long signature can be shown at all: on one line a fifteen-parameter constructor is a horizontal
    scrollbar, and the same thing wrapped is a list you can read down.

    Args:
        function: The function to describe.
        width: The column to break the line at.

    Returns:
        A definition, on one line where it fits and on several where it does not.

    Examples:
        ```python
        parse_function_definition(function)
        # 'def connect(host: str, port: int = 8080) -> None'
        ```
    """

    module = function.package.name
    returns = f" -> {_annotation(function.annotation, module)}" if function.annotation else ""

    return _definition(f"def {function.name}(", _parameter_parts(function), returns, width)


def parse_class_definition(cls: griffe.Class, width: int = 84) -> str:
    """The constructor call as documentation shows it, rather than the `__init__` behind it.

    A class page is titled after the class and its parameters are headed `Constructor Parameters`,
    so the line worth showing is the one a reader would write to build an instance. `def __init__`
    names the method that implements that, which is a different question, and carries a return type
    of `None` where the useful answer is the class the page is about.

    Args:
        cls: The class to describe.
        width: The column to break the line at.

    Returns:
        A constructor call, on one line where it fits and on several where it does not.

    Examples:
        ```python
        parse_class_definition(cls)
        # "Client(host: str = 'localhost')"
        ```
    """

    return _definition(f"{cls.name}(", _parameter_parts(cls), "", width)


def _definition(head: str, parts: Sequence[str], returns: str, width: int) -> str:
    """One call or definition, wrapped when it is too long to read across."""

    one_line = f"{head}{', '.join(parts)}){returns}"
    if len(one_line) <= width:
        return one_line

    # black's shape: one parameter to a line, a trailing comma, and the closing parenthesis
    # carrying the return type
    body = "".join(f"    {part},\n" for part in parts)

    return f"{head}\n{body}){returns}"


def _parameter_parts(parent: griffe.Alias | griffe.Class | griffe.Function) -> list[str]:
    """Each parameter as a definition writes it, with the markers that separate the kinds."""

    module = parent.package.name
    parts: list[str] = []
    parameters = _callable_parameters(parent)

    has_positional_only = any(
        parameter.kind is griffe.ParameterKind.positional_only for parameter in parameters
    )
    positional_only_closed = False
    keyword_only_opened = False

    for parameter in parameters:
        if (
            has_positional_only
            and not positional_only_closed
            and parameter.kind is not griffe.ParameterKind.positional_only
        ):
            parts.append("/")
            positional_only_closed = True

        if parameter.kind is griffe.ParameterKind.keyword_only and not keyword_only_opened:
            parts.append("*")
            keyword_only_opened = True

        match parameter.kind:
            case griffe.ParameterKind.var_positional:
                part = f"*{parameter.name}"
                keyword_only_opened = True

            case griffe.ParameterKind.var_keyword:
                part = f"**{parameter.name}"

            case _:
                part = parameter.name

        if parameter.annotation is not None:
            part += f": {_annotation(parameter.annotation, module)}"
            separator = " = "

        else:
            separator = "="

        if (default := _default(parameter)) is not None:
            part += f"{separator}{default}"

        parts.append(part)

    if has_positional_only and not positional_only_closed:
        parts.append("/")

    return parts


def _callable_parameters(
    parent: griffe.Alias | griffe.Class | griffe.Function,
) -> list[griffe.Parameter]:
    """The parameters a caller passes, without the receiver a bound method is called through.

    A class is asked through its constructor rather than directly, because `griffe.Class`
    reports the parameters of `__init__` alone, and a class built through `__new__` would
    otherwise look like it takes nothing.
    """

    if parent.kind is griffe.Kind.CLASS:
        constructor = _constructor_member(cast(griffe.Class, parent))
        parameters = list(constructor.parameters) if constructor is not None else []

    else:
        parameters = list(parent.parameters)

    if parameters and parameters[0].name in {"self", "cls"}:
        return parameters[1:]

    return parameters


def _constructor_member(cls: griffe.Alias | griffe.Class) -> griffe.Function | None:
    """`__init__` or `__new__`, whichever the class defines, preferring the former.

    Matched on kind rather than by type: a class member is an Alias pointing at the function,
    never a Function.
    """

    for name in ("__init__", "__new__"):
        member = cls.members.get(name)
        if member is not None and member.kind is griffe.Kind.FUNCTION:
            return cast(griffe.Function, member)

    return None


def _attribute_property(attribute: griffe.Attribute, description: str | None = None) -> Property:
    annotation = (
        _annotation(attribute.annotation, attribute.package.name)
        if attribute.annotation is not None
        else None
    )
    # a value that names something private says nothing a reader can use, so the attribute is shown
    # with its type alone
    value = (
        str(attribute.value)
        if attribute.value is not None and not _names_private(attribute.value)
        else None
    )

    return Property(
        attribute.name,
        annotation,
        description,
        value,
        _own_types(attribute.annotation, attribute.package.name),
    )


def strip_stdlib_prefixes(annotation: str) -> str:
    """Drop the module path from the standard library types an annotation names.

    Which module `Path` or `Sequence` lives in is not something a reader has to be told, so the
    path is noise in a signature. Only the standard library is shortened this way, because it is
    the one set of names every Python reader already knows.

    Args:
        annotation: A type as written.

    Returns:
        The annotation with the standard library paths removed.

    Examples:
        ```python
        strip_stdlib_prefixes("dict[str, pathlib.Path]")
        # 'dict[str, Path]'
        ```
    """

    for prefix in _STDLIB_PREFIXES:
        annotation = annotation.replace(prefix, "")

    return annotation


def strip_module_prefix(annotation: str, module: str) -> str:
    """Drop the path from the types `module` defines, leaving every other package qualified.

    A reader of a module's own reference knows where its types come from, so `fumero.Config` reads
    as `Config`. A type from somewhere else keeps its path: shortening `griffe.Module` to `Module`
    would present it as one of the documented module's own, and link it to one.

    Args:
        annotation: A type as written.
        module: The name of the module being documented.

    Returns:
        The annotation with the documented module's own paths cut back to the name at the end.

    Examples:
        ```python
        strip_module_prefix("fumero.model.Module", "fumero")
        # 'Module'
        ```
    """

    own = re.compile(
        rf"\b{re.escape(module)}(?:\.[A-Za-z_][A-Za-z0-9_]*)*\.([A-Za-z_][A-Za-z0-9_]*)"
    )

    return own.sub(r"\1", annotation)


def _own_types(annotation: object, module: str) -> dict[str, str]:
    """The names in `annotation` that `module` defines, each mapped to the path it resolves to.

    Read from griffe's resolution rather than from the text, because the text cannot settle it. A
    module that imports `pathlib.Path` and also defines a `Path` of its own writes both as `Path`,
    and only the name each one resolves to says which is which. So do two modules of one package
    that each define an `Error`.
    """

    if not isinstance(annotation, griffe.Expr):
        return {}

    prefix = f"{module}."

    return {
        name.name: name.canonical_path
        for name in annotation.iterate()
        if isinstance(name, griffe.ExprName) and name.canonical_path.startswith(prefix)
    }


def _annotation(annotation: object, module: str) -> str:
    """One type as the model records it: our own paths taken off, everyone else's left on.

    The standard library keeps its prefix here, and loses it only when a page is written. A link
    is decided from what is recorded, so `pathlib.Path` has to stay distinguishable from a `Path`
    the documented module defines itself, right up until the moment it is displayed.
    """

    return strip_module_prefix(str(annotation), module)
